#'@title
#'Human Region-Specific Expression Analysis Data
#'
#'@description
#'The human region-specific expression analysis (CSEA) data contains two distinct aggregations of the BrainSpan RNAseq data.
#'\itemize{
#'  \item{"human$developmental.periods"}{6 major brain regions across 10 developmental periods}
#'  \item{"human$young.adulthood"}{Young adulthood developmental period across 6 major brain regions}
#'}
#'
#'@details
#'Within each aggregation of the BrainSpan data, two data frames are included. \code{psi.in} is the raw expression matrix for 
#'each aggregation used to calculate the Specificity Index statistic.\code{psi.out} is what is output after calculating the 
#'Specificity Index statistic on \code{psi.in}.
#'\itemize{
#'  \item{\code{human$developmental.periods$psi.in}}\cr{data frame with RPKM values for genes in rows, and 
#'region types in columns (at this point replicate arrays have been averaged, so
#'one column per region type)}
#'  \item{\code{human$developmental.periods$psi.out}}\cr{data frame with identical number of columns & rows as input \code{psi.in} 
#'data frame, with a Specificity Index statistic value (pSI) replacing the expression values for the genes of each region type.}
#'  \item{\code{human$young.adulthood$psi.in}}\cr{data frame with RPKM values for genes in rows, and 
#'region types in columns (at this point replicate arrays have been averaged, so
#'one column per region type)}
#'  \item{\code{human$young.adulthood$psi.out}}\cr{data frame) with identical number of columns & rows as input \code{psi.in} 
#'data frame, with a Specificity Index statistic value (pSI) replacing the expression values for the genes of each region type.}
#'}
#'
#'@examples
#'data(human)
#'
#'@docType data
#'@keywords datasets
#'@format List containing two lists of two dataframes (or could say) Two nested lists of two dataframes within a list
#'@name human
#'@source \url{http://www.brainspan.org}
NULL