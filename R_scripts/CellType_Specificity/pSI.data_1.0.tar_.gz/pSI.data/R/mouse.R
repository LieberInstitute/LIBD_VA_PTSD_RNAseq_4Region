#'@title
#'Mouse Cell-Specific Expression Analysis Data
#'
#'@description
#'The mouse cell-specific expression analysis (CSEA) data contains mouse cell 
#'type specific microarray data from experiments which were conducted on a single platform, 
#'using the published translating ribosome affinity purification (bacTRAP) method.
#'There are 16,907 genes and 35 different cell types used. The cell types are as follows:
#'\itemize{
#'  \item RetC.Cones - Cone cells
#'  \item RetR.Rods - Rod cells
#'  \item Hyp - Hypothalamus
#'  \item Hyp.Hcrt - Hypocretinergic neurons of hypothalamus
#'  \item BF - Basal forebrain
#'  \item BF.Chat - Cholinergic neurons of basal forebrain
#'  \item BS - Brain stem
#'  \item BS.Chat - Cholinergic neurons of brain stem
#'  \item BS.Slc6a4 - Serotonergic neurons of brain stem
#'  \item Cb - Cerebellum
#'  \item Cb.Septin4 - Bergman glia and mature oligodendrocytes of cerebellum
#'  \item Cb.Pcp2 - Purkinje cells of cerebellum
#'  \item Cb.Neurod1 - Granule cells of cerebellum
#'  \item Cb.Lypd6 - Stellate and basket cells of cerebellum
#'  \item Cb.Grp - Unipolar brush cells and Bergman glia of cerebellum
#'  \item Cb.Grm2 - Golgi neurons of cerebellum
#'  \item Cb.Aldh1L1 - Astroglia of cerebellum
#'  \item Cb.Cnp - Oligodendrocyte of cerebellum
#'  \item Cpu - Striatum
#'  \item Cpu.D2 - D2+ medium spiny neurons of striatum
#'  \item Cpu.D1 - D1+ medium spiny neurons of striatum
#'  \item Cpu.Chat - Cholinergic neurons of striatum
#'  \item Ctx - Cortex
#'  \item Ctx.Pdgfrajd340 - OPC of cortex
#'  \item Ctx.Etv1_ts88 - Immune cellsb
#'  \item Ctx.Pnoc - Pnoc+ neurons of cortex
#'  \item Ctx.Ntsr - Ntsr+ neurons of cortex
#'  \item Ctx.Glt25d2 - Glt25d2 neurons of cortex
#'  \item Ctx.Aldh1L1 - Astrocytes of cortex
#'  \item Ctx.Cort - Cort+ neurons of cortex
#'  \item Ctx.Cnp - Oligodendrocyte of cortex
#'  \item Epi - Habenula(epithalamus)
#'  \item Epi.Chat - Cholinergic neurons of habenula
#'  \item Spc - Spinal cord
#'  \item Spc.Chat - Cholinergic neurons of spinal cord
#'}
#'
#'@details
#'Within the list \code{mouse} are three data frames. \code{psi.in} is the raw expression matrix 
#'used to calculate the Specificity Index statistic. \code{psi.in.filter} is a data frame used to 
#'exclude specific genes from the pSI calculation. \code{psi.out} is what is output after calculating 
#'the Specificity Index statistic on \code{psi.in}.
#'\itemize{
#'  \item{\code{mouse$psi.in}}\cr{data frame with expresion values for genes in rows, and 
#'cell types in columns (at this point replicate arrays have been averaged, so
#'one column per cell type)}
#'  \item{\code{mouse$psi.in.filter}}\cr{matched data frame (same genes and samples) but with NA's for any
#'genes that should be excluded for a particular cell type.}
#'  \item{\code{mouse$psi.out}}\cr{data frame with identical number of columns & rows as input \code{psi.in} 
#'data frame, with a Specificity Index statistic value (pSI) replacing the expression values for the genes of each cell type.}
#'}
#'
#'@examples
#'data(mouse)
#'
#'@docType data
#'@keywords datasets
#'@format  List containing two dataframes
#'@name mouse
#'@source \url{http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE13379} \url{http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE30626}
NULL